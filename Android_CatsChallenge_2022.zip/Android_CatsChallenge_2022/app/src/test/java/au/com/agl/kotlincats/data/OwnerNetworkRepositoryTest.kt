package au.com.agl.kotlincats.data

class OwnerNetworkRepositoryTest {
}