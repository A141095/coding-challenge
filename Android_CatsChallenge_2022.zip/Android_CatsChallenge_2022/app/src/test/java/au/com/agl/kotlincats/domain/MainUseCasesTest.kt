package au.com.agl.kotlincats.domain

class MainUseCasesTest {
}