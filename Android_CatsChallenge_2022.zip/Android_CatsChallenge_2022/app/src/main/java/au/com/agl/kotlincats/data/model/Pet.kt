package au.com.agl.kotlincats.data.model

data class Pet(val name: String, val type: String)