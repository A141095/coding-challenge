package au.com.agl.kotlincats.data.model

data class Owner(val name: String, val gender: String, val age: Int, val pets: List<Pet>)